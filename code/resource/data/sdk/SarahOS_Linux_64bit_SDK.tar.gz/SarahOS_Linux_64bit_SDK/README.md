# sarah binary package

### 1, How to install
```
cd ${SARAH_ROOT}/
sudo ./install.sh
```

### 2, How to start
1. service manager
```
sudo service sarah {start|stop|restart}
```

2. boot auto start supported


### 3, How to uninstall
```
cd ${SARAH_ROOT}
sudo ./uninstall.sh
```
